export default class Movie {
  Id?: number;
  Name?: string;
  Price?: number;
  ImageUrl?: string;
}


